package main

import "github.com/strongdm/comply/internal/cli"

func main() {
	cli.Main()
}
