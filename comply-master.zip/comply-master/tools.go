// +build tools

package tools

import (
	_ "github.com/Clever/gitsem"
	_ "github.com/aktau/github-release"
	_ "github.com/containous/go-bindata/go-bindata"              // v1.0.0
	_ "github.com/elazarl/go-bindata-assetfs/go-bindata-assetfs" // v0.0.0-20170227122030-30f82fa23fd8
)
