package gitlab

import (
	"testing"
)

func TestGitlab(t *testing.T) {
	createOne()
}
