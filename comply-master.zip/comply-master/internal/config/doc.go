/*
Package config provides access to the comply.yml file.
*/
package config
