/*
Package cli defines comply commands and arguments.
*/
package cli
