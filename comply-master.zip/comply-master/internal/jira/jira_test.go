package jira

import (
	"testing"
)

func TestJira(t *testing.T) {
	createOne()
}
