package model

type Audit struct {
	ID   string
	Name string
}
