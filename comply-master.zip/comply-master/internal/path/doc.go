/*
Package path provides convenient access to comply project path conventions.
*/
package path
