/*
Package render defines markdown preprocessors, HTML and PDF generation.
*/
package render
