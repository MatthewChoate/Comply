name: System Architecture Narrative
acronym: SAN
majorRevisions:
  - date: Jun 1 2018
    comment: Initial document
---

# System Architecture Narrative

Here we narrate why our org satisfies the control keys listed in the YML block

# Template Coming Soon
