# Standards

All `yaml` files in this directory are assumed to conform to https://github.com/opencontrol/schemas/tree/master/kwalify/standard

Adjust the target standard for this project by adding or removing line-items within each file, or adding/removing a standard file entirely.