id: "offboard"
name: "Offboard User"
---

Resolve this ticket by executing the following steps:

- [ ] Immediately suspend user in SSO
- [ ] Append HR termination request e-mail to this ticket
- [ ] Look up manually-provisioned applications for this role or user
- [ ] Validate access revocation in each
- [ ] Append confirmation or revocation to this ticket