# Procedures

Procedures prescribe specific steps that are taken in response to key events.
